//
//  BT_BLE_Lib.m
//  BTBLEiOSFramework
//
//  Created by Powen Ko on 7/28/14.
//  Copyright (c) 2014 looptek. All rights reserved.
//

#import "UARTPeripheral.h"
#import "BT_BLE_Lib.h"
//#import <AVFoundation/AVFoundation.h>


typedef enum
{
    LOGGING,
    RX,
    TX,
} ConsoleDataType;



@interface BT_BLE_Lib()
@property CBCentralManager *cm;
@property ConnectionState state;
@property UARTPeripheral *currentPeripheral;
@end



@implementation BT_BLE_Lib
@synthesize cm = _cm;
@synthesize currentPeripheral = _currentPeripheral;
@synthesize delegate=_delegate;


-(id)init{
    id t1=[super init];
	// Do any additional setup after loading the view, typically from a nib.
    self.cm = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    [self.currentPeripheral setDelegate:self];
    [self addTextToConsole:@"Did start application" dataType:LOGGING];
    NSLog(@"BT_BLE_Lib:init()");
    return t1;
}

- (bool) DigitalOut:(int) pin onOff:(BOOL)onOff
{
    int inPin = 0;
    inPin = pin;
    bool pinStatus = false;
    pinStatus = onOff;
    return true;
}

- (bool) DigitalIn:(int) pin
{
    int intPin = 0;
    intPin = pin;
    return true;
}

- (void) UARTSend:(NSString*)message
{
    if (message.length == 0){
        return;
    }
    [self addTextToConsole:message dataType:TX];
    [self.currentPeripheral writeString:message];
}
/*
- (bool) BlueToothConnect:(BOOL)onOff
{
    return self.state; //BlueToothConnectStatus;
}
*/
- (int)   BlueToothConnectStatus
{
    return self.state;
}

//  找 iBeacon
- (int)  iBeaconStartScan{
    NSLog(@"BT_BLE_Lib:iBeaconStartScan()");
    BLEMode=1;
    [self.cm stopScan];
    NSDictionary *options = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:YES] forKey:CBCentralManagerScanOptionAllowDuplicatesKey];
    [self.cm scanForPeripheralsWithServices:nil options:options];
    NSLog(@"iBeaconStartScan ...");
    self.state=IBEACONSCAN;
    return  self.state;
}

//  停止 iBeacon
- (int)  iBeaconStopScan{
    
    NSLog(@"BT_BLE_Lib:iBeaconStopScan()");
    NSLog(@"iBeaconStopScan ...");
    BLEMode=0;
    [self.cm stopScan];
    self.state=IDLE;
    return  self.state;
}

- (int) ConnectBlueTooth
{
    NSString* str;
    NSLog(@"BT_BLE_Lib:ConnectBlueTooth() state:%d",self.state);
    BLEMode=2;
    switch (self.state) {
        case IDLE:
            self.state = SCANNING;
            NSLog(@"Started scan ...");
            [_delegate BlueToothStatus :@"Started scan ..."];
            [self.cm scanForPeripheralsWithServices:@[UARTPeripheral.uartServiceUUID] options:@{CBCentralManagerScanOptionAllowDuplicatesKey: [NSNumber numberWithBool:NO]}];
            break;
            
        case SCANNING:
            self.state = IDLE;
            NSLog(@"Stopped scan");
            [_delegate BlueToothStatus :@"Stopped scan"];
            [self.cm stopScan];
            break;
            
        case CONNECTED:
            str =[NSString stringWithFormat:@"Disconnect peripheral %@",self.currentPeripheral.peripheral.name];
            [_delegate BlueToothStatus :str];
            [self.cm cancelPeripheralConnection:self.currentPeripheral.peripheral];
            
            break;
    }
    
    return self.state;
}

#pragma mark BTCode
- (void) addTextToConsole:(NSString *) string dataType:(ConsoleDataType) dataType
{
    NSString *direction;
    switch (dataType)
    {
        case RX:
            direction = @"RX";
            break;
            
        case TX:
            direction = @"TX";
            break;
            
        case LOGGING:
            direction = @"Log";
    }
    
    NSDateFormatter *formatter;
    formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"HH:mm:ss.SSS"];
}


- (void) didReadHardwareRevisionString:(NSString *)string
{
    [_delegate DidReadHardwareRevisionString :[NSString stringWithFormat:@"Hardware revision: %@", string] ];
    
}

-(int) FunPins_inputDisplay_osaka_1:(NSString*) i_string{
    // 0 是 DigitalInputPinsChanges
    // 1 是 UART
    // 2 是 	@"`~201234567890123\"	0x14e0d770
    // osaka 是 156 050198470413\r
    /*
     int reValue=0;
     int t1=[i_string length];
     if(t1<11){ reValue=1;    return reValue;  }
     
     NSString* mystr=[i_string substringWithRange:NSMakeRange(0,1)];
     if([mystr isEqualToString:@"`"])  reValue=0;
     mystr=[i_string substringWithRange:NSMakeRange(1,1)];
     if(reValue==0  &&  [mystr isEqualToString:@"~"])  reValue=0;
     mystr=[i_string substringWithRange:NSMakeRange(10,1)];
     if(t1==11 &&  reValue==0 ){
     if(![mystr isEqualToString:@"\\"]) reValue=0;
     }else  if(t1>=11 &&  reValue==0 ){
     mystr=[i_string substringWithRange:NSMakeRange(t1-1,1)];
     if([mystr isEqualToString:@"\\"])  reValue=2;
     mystr=[i_string substringWithRange:NSMakeRange(0,1)];
     if([mystr isEqualToString:@"1"]  || [mystr isEqualToString:@"0"])  reValue=0;
     }else{
     reValue=1;
     }
     */
    //return reValue;
    
    NSString* mystr=[i_string substringWithRange:NSMakeRange(0,1)];
    if([mystr isEqualToString:@"`"])  return 0; //=0;
    return  1;
}




-(int) FunPins_inputDisplay:(NSString*) i_string{
    // 0 是 DigitalInputPinsChanges
    // 1 是 UART
    // 2 是 	@"`~201234567890123\"	0x14e0d770
    int reValue=0;
    NSUInteger t1=[i_string length];
    if(t1<11){ reValue=1;    return reValue;  }
    
    NSString* mystr=[i_string substringWithRange:NSMakeRange(0,1)];
    if([mystr isEqualToString:@"`"])  reValue=0;
    mystr=[i_string substringWithRange:NSMakeRange(1,1)];
    if(reValue==0  &&  [mystr isEqualToString:@"~"])  reValue=0;
    mystr=[i_string substringWithRange:NSMakeRange(10,1)];
    if(t1==11 &&  reValue==0 ){
        if(![mystr isEqualToString:@"\\"]) reValue=0;
    }else  if(t1>=11 &&  reValue==0 ){
        mystr=[i_string substringWithRange:NSMakeRange(t1-1,1)];
        if([mystr isEqualToString:@"\\"])  reValue=2;
        mystr=[i_string substringWithRange:NSMakeRange(0,1)];
        if([mystr isEqualToString:@"1"]  || [mystr isEqualToString:@"0"])  reValue=0;
    }else{
        reValue=1;
    }
    return reValue;
}


- (void) didReceiveData:(NSString *)string
{
    @try {
        
        NSLog(@"BT_BLE_Lib:didReceiveData()");
        
        int t1=[self FunPins_inputDisplay_osaka_1:string];
        
        NSLog(@"BT_BLE_Lib:didReceiveData() string:%@",string);
        if(t1==0){
            NSString* t1= [string substringWithRange:NSMakeRange(2,8)];
            [_delegate DigitalInputPinsChanges :[NSString stringWithFormat:@"%@", t1] ];
        }else{
            [_delegate DidReceiveData :[NSString stringWithFormat:@"%@", string] ];
        }
    }
    @catch (NSException * e) {
        NSLog(@"Exception: %@", e);
    }
    @finally {
        // Added to show finally works as well
    }
    
    
}

- (void) centralManagerDidUpdateState:(CBCentralManager *)central
{
    NSString *stateString = nil;
    switch(central.state) //bluetoothManager.state)
    {
        case CBCentralManagerStateResetting: stateString = @"The connection with the system service was momentarily lost, update imminent."; break;
        case CBCentralManagerStateUnsupported: stateString = @"The platform doesn't support Bluetooth Low Energy."; break;
        case CBCentralManagerStateUnauthorized: stateString = @"The app is not authorized to use Bluetooth Low Energy."; break;
        case CBCentralManagerStatePoweredOff: stateString = @"State Powered Off"; break;
        case CBCentralManagerStatePoweredOn: stateString = @"State Powered On"; break;
        default: stateString = @"State unknown, update imminent."; break;
    }
    [_delegate BlueToothStatus :stateString]; //@"State Powered On"];
    /*
    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"Bluetooth state"
                                                     message:stateString
                                                    delegate:nil
                                           cancelButtonTitle:@"Okay" otherButtonTitleArray:nil] autorelease];
    [alert show];
    */
    /*
    if (central.state == CBCentralManagerStatePoweredOn)
    {
        [_delegate BlueToothStatus :@"State Powered On"];
    }*/
}

- (void) centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
    if(BLEMode==1){
        // Reject any where the value is above reasonable range
        //   if (RSSI.integerValue > -15) {
        //       return;
        //   }
        
        // Reject if the signal strength is too low to be close enough (Close is around -22dB)
        //   if (RSSI.integerValue < -35) {
        //       return;
        //   }
        //   NSString*string=[NSString stringWithFormat:@"Discovered %@ at %@", peripheral.name, RSSI];
        NSString* t_name=peripheral.name;
        NSLog(@"Discovered %@ at %@",t_name , RSSI);
        
        /*
        if ([t_name rangeOfString:@"iFrogLAB"].length > 0) {
        }else{
            return;
        }
        */
        [_delegate DidReceiveiBeacon:peripheral.name
                                    RSSI:RSSI Action:@"FIND"];
        
    }else{
        NSLog(@"Did discover peripheral %@", peripheral.name);
        [self.cm stopScan];
    
        self.currentPeripheral = [[UARTPeripheral alloc] initWithPeripheral:    peripheral delegate:self];
    
        [self.cm connectPeripheral:peripheral options:@{CBConnectPeripheralOptionNotifyOnDisconnectionKey: [NSNumber numberWithBool:YES]}];
    }
}

- (void) centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    NSLog(@"Did connect peripheral %@", peripheral.name);
    
    [self addTextToConsole:[NSString stringWithFormat:@"Did connect to %@", peripheral.name] dataType:LOGGING];
    
    self.state = CONNECTED;
    [_delegate BlueToothStatus :@"Connected"];
    if ([self.currentPeripheral.peripheral isEqual:peripheral]){
        [self.currentPeripheral didConnect];
    }
    
    
    

   // [peripheral setDelegate:self];
   // [peripheral discoverServices:nil];
    NSString* connected = [NSString stringWithFormat:@"Connected: %@", peripheral.state == CBPeripheralStateConnected ? @"YES" : @"NO"];
    NSLog(@"%@", connected);
    
    
}

- (void) centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@"Did disconnect peripheral %@", peripheral.name);
    
    [self addTextToConsole:[NSString stringWithFormat:@"Did disconnect from %@", peripheral.name] dataType:LOGGING];
    
    self.state = IDLE;

    [_delegate BlueToothStatus :@"Disconnected"];
    
    if ([self.currentPeripheral.peripheral isEqual:peripheral])
    {
        [self.currentPeripheral didDisconnect];
    }
}


- (void)DigitalOuts:(NSString*)sender {
    NSString* t_send=[NSString stringWithFormat:@"`~%@\\",sender                      ];
    [self.currentPeripheral writeString:t_send];
}
- (void) DigitalInput{
    
    NSString* t_send=[NSString stringWithFormat:@"`~201234567890123\\"];
    //  int t1=[t_send length];
    [self.currentPeripheral writeString:t_send];
    
}


@end
