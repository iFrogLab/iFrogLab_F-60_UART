//
//  MainViewController.h
//  BTBLEiOSFramework
//
//  Created by Powen Ko on 7/28/14.
//  Copyright (c) 2014 looptek. All rights reserved.
//

#import "FlipsideViewController.h"

@interface MainViewController : UIViewController <FlipsideViewControllerDelegate, UIPopoverControllerDelegate>

@property (strong, nonatomic) UIPopoverController *flipsidePopoverController;

@end
