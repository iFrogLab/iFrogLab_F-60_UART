//
//  main.m
//  BTBLEiOSFramework
//
//  Created by Powen Ko on 7/28/14.
//  Copyright (c) 2014 looptek. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
