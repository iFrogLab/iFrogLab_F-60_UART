/** Automatically generated file. DO NOT MODIFY */
package com.powenko.myimageviewer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}